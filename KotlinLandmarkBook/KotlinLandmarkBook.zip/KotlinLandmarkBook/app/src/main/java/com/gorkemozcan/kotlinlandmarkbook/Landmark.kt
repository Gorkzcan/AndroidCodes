package com.gorkemozcan.kotlinlandmarkbook

class Landmark (val name: String, val country:String, val image:Int){

}