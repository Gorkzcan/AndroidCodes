# Chords-Follower
This application helps guitarists to follow the chords of the song easily by scrolling the webview in a certain speed that user enters.
